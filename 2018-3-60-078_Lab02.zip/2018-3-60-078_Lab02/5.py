string="All our dreams will come true if we have the courage to pursue them."
new=" "
s=string.split(new)

for i in range (0,len(s)):
    if(len(s[i])<5 ):
        print(s[i])